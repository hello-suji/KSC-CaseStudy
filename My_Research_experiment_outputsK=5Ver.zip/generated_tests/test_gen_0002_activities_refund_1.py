import pytest
import importlib

activities = importlib.import_module('activities')
refund = getattr(activities, 'refund', None)

@pytest.mark.asyncio
def test_refund_with_positive_amount_hits_confirmation_use(monkeypatch):
    if refund is None:
        pytest.skip('refund function is not available in activities module')

    class MockTemporalClient:
        pass

    class MockWorker:
        async def refund_mock(*args, **kwargs):
            return 'Mock Confirmation'

    monkeypatch.setattr('temporalio.client.Client', lambda *args, **kwargs: MockTemporalClient())
    monkeypatch.setattr('temporalio.worker.Worker', lambda *args, **kwargs: MockWorker())

    result = await refund(amount=10)
    assert result == 'Mock Confirmation'

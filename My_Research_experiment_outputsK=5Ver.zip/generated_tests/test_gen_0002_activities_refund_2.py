import pytest
import importlib

activities = importlib.import_module('activities')
refund = getattr(activities, 'refund', None)

@pytest.mark.asyncio
def test_refund_with_zero_amount_raises_exception(monkeypatch):
    if refund is None:
        pytest.skip('refund function is not available in activities module')

    class MockTemporalClient:
        pass

    class MockWorker:
        async def refund_mock(*args, **kwargs):
            raise ValueError('Amount must be greater than zero')

    monkeypatch.setattr('temporalio.client.Client', lambda *args, **kwargs: MockTemporalClient())
    monkeypatch.setattr('temporalio.worker.Worker', lambda *args, **kwargs: MockWorker())

    with pytest.raises(ValueError, match='Amount must be greater than zero'):
        await refund(amount=0)

import importlib
import pytest

@pytest.mark.asyncio
def test_refund_line_58_false(monkeypatch):
    activities = importlib.import_module('activities')
    refund = getattr(activities, 'refund', None)
    if refund is None:
        pytest.skip('refund function not found')

    async def fake_process_refund(amount):
        return False

    # Patch the process_refund simulation function to always return False
    monkeypatch.setattr(activities, 'process_refund', fake_process_refund)
    
    amount = 100.0
    confirmation = await refund(amount)
    
    assert confirmation is False, f'Expected confirmation to be False, got {confirmation}'

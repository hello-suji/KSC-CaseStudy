import pytest
import importlib


def test_refund_successful_path_lines_58_62(monkeypatch):
    activities = importlib.import_module('activities')
    refund = getattr(activities, 'refund', None)
    if refund is None:
        pytest.skip('refund not implemented yet')

    # Mock any needed I/O, network or environment variables
    monkeypatch.setattr('builtins.print', lambda *args, **kwargs: None)

    # Use input that would pass the first branch without exception
    transaction_id = 'txn_12345'
    amount = 100.0

    confirmation = refund(transaction_id, amount)
    assert confirmation == 'Refund processed successfully'

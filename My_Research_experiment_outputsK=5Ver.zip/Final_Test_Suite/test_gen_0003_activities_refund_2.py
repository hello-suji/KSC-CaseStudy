import pytest
import importlib


def test_refund_raises_exception_line_58(monkeypatch):
    activities = importlib.import_module('activities')
    refund = getattr(activities, 'refund', None)
    if refund is None:
        pytest.skip('refund not implemented yet')

    # Mock any needed I/O, network or environment variables
    monkeypatch.setattr('builtins.print', lambda *args, **kwargs: None)

    # Use input that would raise an exception e.g., invalid transaction
    transaction_id = 'invalid_txn'
    amount = -1.0

    with pytest.raises(ValueError, match='Invalid refund request'):
        refund(transaction_id, amount)

import importlib
import pytest

@pytest.mark.asyncio
def test_refund_line_58_and_59(monkeypatch):
    activities = importlib.import_module('activities')
    refund = getattr(activities, 'refund', None)
    if refund is None:
        pytest.skip('refund function not found')

    # Simulate a valid refund process leading to a False confirmation
    async def fake_process_refund(amount):
        assert amount == 100.0
        return False

    # Patch the process_refund function to simulate the scenario
    monkeypatch.setattr(activities, 'process_refund', fake_process_refund)

    amount = 100.0
    confirmation = await refund(amount)

    # Assert the confirmation is False triggering lines 58 and 59
    assert confirmation is False, f'Expected confirmation to be False, got {confirmation}'

@pytest.mark.asyncio
def test_refund_line_62(monkeypatch):
    activities = importlib.import_module('activities')
    refund = getattr(activities, 'refund', None)
    if refund is None:
        pytest.skip('refund function not found')

    # Simulate a process that raises an exception
    async def fake_process_refund(amount):
        raise Exception('Mock exception triggering line 62')

    # Patch the process_refund function to raise an exception
    monkeypatch.setattr(activities, 'process_refund', fake_process_refund)

    amount = 100.0
    with pytest.raises(Exception, match='Mock exception triggering line 62'):
        await refund(amount)

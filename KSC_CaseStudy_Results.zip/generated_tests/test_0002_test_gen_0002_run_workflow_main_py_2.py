import pytest
import importlib
from unittest.mock import Mock


def test_main_try_block_hits_L22_exception_case(monkeypatch):
    module_name = 'run_workflow'
    mod = importlib.import_module(module_name)
    main = getattr(mod, 'main', None)
    if main is None:
        pytest.skip('main missing')

    # Mock the Client and Worker to prevent actual Temporal calls.
    mock_client = Mock()
    monkeypatch.setattr('temporalio.client.Client', mock_client)

    # Mock workflow execution with exception
    mock_client.run_workflow.side_effect = Exception('Workflow failed')

    # Test if calling main raises the expected exception
    with pytest.raises(Exception, match='Workflow failed'):
        main()

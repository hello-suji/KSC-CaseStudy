import importlib
import pytest

# Load the module using importlib
mod = importlib.import_module('banking_service')

# Access the 'deposit' function
deposit = getattr(mod, 'deposit', None)
if deposit is None:
    pytest.skip('deposit function missing')

def test_deposit_raises_exception_hits_L171():
    # Assuming the function takes an account and amount as arguments
    account = {'balance': 100}
    amount = -50  # A negative amount to trigger the raise
    with pytest.raises(ValueError, match='Amount must be positive'):
        deposit(account, amount)  # Expect exception on negative amount

import importlib
import pytest
from unittest import mock

# Attempt to load the module and fetch the function
mod = importlib.import_module('run_workflow')
main = getattr(mod, 'main', None)
if main is None:
    pytest.skip('main function missing')

@pytest.mark.asyncio
def test_main_handles_WorkflowFailureError_hits_L32(monkeypatch):
    # Mock Temporal Client to raise WorkflowFailureError
    mock_client = mock.Mock()
    mock_client.execute_workflow.side_effect = mod.WorkflowFailureError("Test failure")
    
    # Patch the client creation to return the mock client
    monkeypatch.setattr('temporalio.client.Client', lambda *args, **kwargs: mock_client)
    
    with pytest.raises(mod.WorkflowFailureError, match="Test failure"):
        await main()

    assert mock_client.execute_workflow.called

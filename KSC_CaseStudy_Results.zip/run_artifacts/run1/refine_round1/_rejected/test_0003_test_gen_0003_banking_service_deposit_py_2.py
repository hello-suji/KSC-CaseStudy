import importlib
import pytest

# Load the module using importlib
mod = importlib.import_module('banking_service')

# Access the 'deposit' function
deposit = getattr(mod, 'deposit', None)
if deposit is None:
    pytest.skip('deposit function missing', allow_module_level=True)

def test_deposit_with_negative_amount_raises_exception_hits_L171():
    # Assuming the function takes an account and amount as arguments
    account = {'balance': 100}
    amount = -50  # A negative amount to trigger the raise
    with pytest.raises(ValueError, match='Amount must be positive'):
        deposit(account, amount)  # Expect exception on negative amount

# Test with zero to check for non-positive amount guard

def test_deposit_with_zero_amount_raises_exception_hits_L171():
    account = {'balance': 100}
    amount = 0  # Zero amount to also trigger the raise
    with pytest.raises(ValueError, match='Amount must be positive'):
        deposit(account, amount)  # Expect exception on non-positive amount

import importlib
import pytest

def test_deposit_invalid_account_raises_exception_hits_L47(monkeypatch):
    mod = importlib.import_module('activities')
    deposit = getattr(mod, 'deposit', None)
    if deposit is None:
        pytest.skip('deposit function missing')

    def mock_add_money(account_id, amount):
        if account_id != 'valid-account-updated':
            raise ValueError('Invalid account ID')
        return True

    monkeypatch.setattr(mod, 'add_money', mock_add_money)

    # Setup an invalid account situation
    account_id = 'invalid-account'
    amount = 100
    # Test the deposit function for exception
    with pytest.raises(ValueError, match='Invalid account ID'):
        deposit(account_id, amount)

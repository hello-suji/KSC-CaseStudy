import pytest
import importlib

# Load the module using importlib
module_name = 'banking_service'
mod = importlib.import_module(module_name)

tgt = getattr(mod, 'deposit_that_fails', None)

if tgt is None:
    pytest.skip('deposit_that_fails missing', allow_module_level=True)


def test_deposit_that_fails_raises_valueerror_hits_L193():
    with pytest.raises(ValueError, match='This deposit has failed.'):
        # Call the function expecting it to raise the specified ValueError
        # Pass necessary parameters if any to make sure it triggers the error on line 193
        tgt(some_invalid_input)

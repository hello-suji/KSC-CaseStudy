import pytest
import importlib

def get_deposit_function():
    try:
        module = importlib.import_module('activities')
        return getattr(module, 'deposit', None)
    except ImportError:
        pytest.skip('activities module not available')


def test_deposit_negative_amount_raises_exception_hits_L46_L47():
    deposit = get_deposit_function()
    if deposit is None:
        pytest.skip('deposit function not available')

    account_id = 'test_account'
    amount = -100  # This should raise an exception due to negative deposit amount

    with pytest.raises(ValueError, match='Deposit amount must be greater than zero.'):
        deposit(account_id, amount)

import importlib
import pytest

activities = importlib.import_module('activities')

class InvalidAccountError(Exception):
    pass

def test_refund_hits_L58_L59_and_raises(monkeypatch):
    refund = getattr(activities, 'refund', None)
    if refund is None:
        pytest.skip('refund function not found')

    def mock_check_account(account_id):
        return False  # Simulate account not found to hit line 58, 59

    def mock_process_refund(account_id, amount):
        raise InvalidAccountError('Account not found')

    monkeypatch.setattr(activities, 'check_account', mock_check_account)
    monkeypatch.setattr(activities, 'process_refund', mock_process_refund)

    with pytest.raises(InvalidAccountError, match='Account not found'):
        refund('nonexistent_account', 50)

    assert not mock_check_account('nonexistent_account')  # To verify the check_account mock was invoked

import pytest
import importlib

@pytest.mark.parametrize("amount, expected_confirmation", [(0, 'Failed'), (100, 'Success'), (-1, 'Invalid Amount')])
def test_refund_hits_L58_59_62(monkeypatch, amount, expected_confirmation):
    module = importlib.import_module('activities')
    refund = getattr(module, 'refund', None)
    if refund is None:
        pytest.skip('refund function not found')

    def mock_refund(account_id, amount):
        if amount <= 0:
            return 'Invalid Amount'
        elif amount == 100:
            return 'Success'
        return 'Failed'

    monkeypatch.setattr(refund, 'refund', mock_refund)
    confirmation = refund('account_id', amount)
    assert confirmation == expected_confirmation

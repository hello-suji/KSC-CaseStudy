import pytest
import importlib

# Importing the function using importlib
activities = importlib.import_module('activities')
refund = getattr(activities, 'refund', None)

@pytest.mark.skipif(refund is None, reason='refund function not available')
def test_refund_successful_confirmation_return():
    # Test for successful refund scenario
    refund_id = 'ref123'
    amount = 100.0
    confirmation = refund(refund_id, amount)

    # Assert the confirmation is as expected
    assert confirmation == f'Refund {refund_id} of amount {amount} confirmed'

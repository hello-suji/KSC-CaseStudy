import importlib
import pytest

activities = importlib.import_module('activities')

class InvalidAccountError(Exception):
    pass

def test_refund_line_58_false_exception(monkeypatch):
    refund = getattr(activities, 'refund', None)
    if refund is None:
        pytest.skip('refund function not found')
    
    def mock_process_refund(account_id, amount):
        raise InvalidAccountError('Invalid account')

    monkeypatch.setattr(activities, 'process_refund', mock_process_refund)
    
    with pytest.raises(InvalidAccountError, match='Invalid account'):
        refund('invalid_account', 100)

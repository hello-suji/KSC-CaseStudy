import pytest
import importlib

def get_deposit_function():
    try:
        module = importlib.import_module('activities')
        return getattr(module, 'deposit', None)
    except ImportError:
        pytest.skip('activities module not available')


def test_deposit_zero_amount_raises_exception_hit_line_47():
    deposit = get_deposit_function()
    if deposit is None:
        pytest.skip('deposit function not available')

    account_id = 'test_account'
    amount = 0  # This should raise an exception

    with pytest.raises(ValueError, match='Deposit amount must be greater than zero.'):
        deposit(account_id, amount)

import pytest
import importlib

# Importing the function using importlib
activities = importlib.import_module('activities')
refund = getattr(activities, 'refund', None)

@pytest.mark.skipif(refund is None, reason='refund function not available')
def test_refund_raises_exception():
    # Test to hit exception scenario
    refund_id = 'ref123'
    amount = -50.0  # Negative amount to trigger exception
    
    # Assert that exception is raised with the right message
    with pytest.raises(ValueError, match='Amount must be positive'):  # Assuming exception message
        refund(refund_id, amount)

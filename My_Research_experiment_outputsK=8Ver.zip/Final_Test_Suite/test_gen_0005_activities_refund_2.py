import pytest
import importlib

@pytest.mark.parametrize("amount, expected_confirmation", [(0, 'Failed')])
def test_refund_branch_line_58_false(monkeypatch, amount, expected_confirmation):
    module = importlib.import_module('activities')
    refund = getattr(module, 'refund', None)
    if refund is None:
        pytest.skip('refund function not found')

    original_function = getattr(refund, '__wrapped__', refund)

    def mock_refund(account_id, amount):
        return 'Failed'

    monkeypatch.setattr(original_function, 'refund', mock_refund)
    confirmation = refund('account_id', amount)
    assert confirmation == expected_confirmation

import importlib
import pytest

activities = importlib.import_module('activities')

def test_refund_line_58_true(monkeypatch):
    refund = getattr(activities, 'refund', None)
    if refund is None:
        pytest.skip('refund function not found')
    
    def mock_process_refund(account_id, amount):
        return True
    
    monkeypatch.setattr(activities, 'process_refund', mock_process_refund)
    
    confirmation = refund('valid_account', 100)
    assert confirmation == 'Refund successful'

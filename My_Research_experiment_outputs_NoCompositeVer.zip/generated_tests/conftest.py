import os, asyncio, pytest, importlib, inspect

@pytest.fixture(autouse=True)
def _no_real_net_env(monkeypatch):
    monkeypatch.setenv('NO_PROXY', '*')
    for k in ['HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy','ALL_PROXY','all_proxy']:
        monkeypatch.delenv(k, raising=False)

@pytest.fixture(autouse=True)
def _patch_time(monkeypatch):
    import time
    monkeypatch.setattr(time, 'sleep', lambda *_: None, raising=False)

@pytest.fixture(autouse=True)
def _patch_temporal(monkeypatch):
    try:
        import temporalio  # noqa: F401
    except Exception:
        return
    class _Dummy:
        def __init__(self, *a, **k): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): pass
        def __call__(self, *a, **k): return self
        async def run(self, *a, **k): return None
        async def start(self, *a, **k): return None
    for path in ['temporalio.client.Client','temporalio.worker.Worker','temporalio.workflow.Workflow']:
        try:
            mod_name, attr = path.rsplit('.', 1)
            mod = importlib.import_module(mod_name)
            setattr(mod, attr, _Dummy)
        except Exception:
            pass

def _wrap_async(func):
    if inspect.iscoroutinefunction(func):
        def sync_wrapper(*a, **k):
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            return loop.run_until_complete(func(*a, **k))
        return sync_wrapper
    return func

_TARGET_MODULES = [
    'run_worker_module',
    'run_workflow_module',
    'run_workflow_main',
]

@pytest.fixture(autouse=True)
def _wrap_async_entrypoints(monkeypatch):
    for mod_name in _TARGET_MODULES:
        try:
            mod = importlib.import_module(mod_name)
        except Exception:
            continue
        for attr in ('main','run','start'):
            if hasattr(mod, attr):
                try:
                    monkeypatch.setattr(mod, attr, _wrap_async(getattr(mod, attr)), raising=False)
                except Exception:
                    pass
    def _safe_run(coro):
        if inspect.iscoroutine(coro):
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            return loop.run_until_complete(coro)
        return coro
    monkeypatch.setattr(asyncio, 'run', _safe_run, raising=False)

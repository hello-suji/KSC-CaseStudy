import importlib
import pytest

banking_service = importlib.import_module('banking_service')

def test_deposit_negative_amount_raise_hits_L170_and_L171():
    deposit_function = getattr(banking_service, 'deposit', None)
    if deposit_function is None:
        pytest.skip('Function deposit not found in banking_service')
    account = {'balance': 100}
    amount = -10
    with pytest.raises(ValueError) as exc_info:
        deposit_function(account, amount)
    assert 'Amount must be positive' in str(exc_info.value)

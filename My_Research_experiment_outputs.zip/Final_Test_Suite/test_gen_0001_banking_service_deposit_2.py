import importlib
import pytest

banking_service = importlib.import_module('banking_service')

def test_deposit_negative_amount_raise_line_171():
    deposit_function = getattr(banking_service, 'deposit', None)
    if deposit_function is None:
        pytest.skip('Function deposit not found in banking_service')
    account = {'balance': 100}
    amount = -10
    with pytest.raises(ValueError, match='Amount must be positive'):  # Adjust the message to expected exception message
        deposit_function(account, amount)

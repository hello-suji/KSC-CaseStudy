import pytest
import importlib

banking_service = importlib.import_module('banking_service')


def test_deposit_invalid_account_error_line_170():
    deposit = getattr(banking_service, 'deposit', None)
    if deposit is None:
        pytest.skip('deposit function not found')

    with pytest.raises(banking_service.InvalidAccountError):
        deposit(account_id='invalid_account', amount=100)

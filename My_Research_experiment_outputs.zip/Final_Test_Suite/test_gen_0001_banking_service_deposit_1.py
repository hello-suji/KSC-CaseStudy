import importlib
import pytest

banking_service = importlib.import_module('banking_service')

def test_deposit_positive_amount_line_170():
    deposit_function = getattr(banking_service, 'deposit', None)
    if deposit_function is None:
        pytest.skip('Function deposit not found in banking_service')
    account = {'balance': 100}
    amount = 50
    deposit_function(account, amount)
    assert account['balance'] == 150, 'Balance should be updated with positive amount'

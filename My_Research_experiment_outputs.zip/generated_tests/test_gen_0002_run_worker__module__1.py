def test_hit_branch_line_25_true(monkeypatch):
    import importlib
    try:
        module = importlib.import_module('run_worker')
    except ImportError:
        import pytest
        pytest.skip('run_worker module could not be imported')

    def mock_worker(*args, **kwargs):
        return True

    monkeypatch.setattr('temporalio.worker.Worker', mock_worker)

    assert getattr(module, 'some_branch_condition')() is True

import sys
import pytest
import importlib

@pytest.mark.skipif(sys.version_info < (3, 6), reason="requires python3.6+")
def test_refund_branch_line_58_confirmation_false():
    modules = importlib.import_module('activities')
    refund = getattr(modules, 'refund', None)

    if refund is None:
        pytest.skip('refund function is not available')
    
    # Parameters to trigger the branch at line 58 where confirmation is False
    amount = 100
    confirmation = False

    with pytest.raises(Exception, match="Refund cannot proceed without confirmation"):
        refund(amount=amount, confirmation=confirmation)

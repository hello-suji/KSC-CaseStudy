import sys
import pytest
import importlib

@pytest.mark.skipif(sys.version_info < (3, 6), reason="requires python3.6+")
def test_refund_branch_line_58_confirmation_true():
    modules = importlib.import_module('activities')
    refund = getattr(modules, 'refund', None)

    if refund is None:
        pytest.skip('refund function is not available')

    # Parameters to take the positive branch where confirmation is True
    amount = 100
    confirmation = True

    result = refund(amount=amount, confirmation=confirmation)
    
    # Assert the result is as expected
    assert result is not None
    assert result == 'Refund successful'

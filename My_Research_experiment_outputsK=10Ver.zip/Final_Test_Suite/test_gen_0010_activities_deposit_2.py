import pytest
import importlib

try:
    activities = importlib.import_module('activities')
    deposit_func = getattr(activities, 'deposit', None)
except ImportError:
    deposit_func = None
    activities = None


def test_deposit_hits_L46_L50():
    if deposit_func is None:
        pytest.skip('The deposit function is not implemented in the activities module.')
    
    account = {'balance': 100}
    amount = -50

    with pytest.raises(ValueError) as exc_info:
        deposit_func(account, amount)  # This should raise ValueError and hit the target lines 46 and 50

    assert str(exc_info.value) == 'Deposit amount must be positive', "Unexpected exception message"
    assert account['balance'] == 100, "Balance should not change when deposit fails"

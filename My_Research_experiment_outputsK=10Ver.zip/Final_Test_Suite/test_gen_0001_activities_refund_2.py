import importlib
import pytest

activities = importlib.import_module('activities')
refund = getattr(activities, 'refund', None)

@pytest.mark.skipif(refund is None, reason='refund not implemented yet')
def test_refund_invalid_account_exception_branch_63(monkeypatch):
    
    def mock_check_account(account_id):
        return False
    
    monkeypatch.setattr(activities, 'check_account', mock_check_account)

    account_id = 999
    amount = 100.0
    confirmation = True
    
    with pytest.raises(activities.InvalidAccountError, match='Invalid account 999'):
        refund(account_id, amount, confirmation)

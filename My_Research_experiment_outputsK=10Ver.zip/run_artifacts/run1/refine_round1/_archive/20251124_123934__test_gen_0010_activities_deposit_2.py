import pytest
import importlib

activities = importlib.import_module('activities')

def test_deposit_exception_line_50():
    # Assuming `account` is an object that supports deposit method
    account = {'balance': 100}
    amount = -50  # This should trigger the exception

    with pytest.raises(ValueError) as exc_info:
        activities.deposit(account, amount)

    assert str(exc_info.value) == 'Deposit amount must be positive', "Unexpected exception message"

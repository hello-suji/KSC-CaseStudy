import sys
import pytest
import importlib

@pytest.mark.skipif(sys.version_info < (3, 6), reason="requires python3.6+")
def test_refund_hits_L58_L59_L62():
    modules = importlib.import_module('activities')
    refund = getattr(modules, 'refund', None)

    if refund is None:
        pytest.skip('refund function is not available')

    # Parameters to trigger all target lines
    amount = 200  # Assuming this amount hits both positive and branch logic
    confirmation = True

    result = refund(amount=amount, confirmation=confirmation)
    
    # Assert the result is as expected
    assert result is not None
    assert result == 'Refund successful'

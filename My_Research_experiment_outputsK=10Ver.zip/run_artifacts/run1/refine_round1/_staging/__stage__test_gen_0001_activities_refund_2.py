import importlib
import pytest

activities = importlib.import_module('activities')
refund = getattr(activities, 'refund', None)

@pytest.mark.skipif(refund is None, reason='refund not implemented yet')
def test_refund_invalid_account_exception_branch_63_and_58_59(monkeypatch):

    def mock_check_account(account_id):
        return False

    def mock_calculate_refund_amount(account_id, amount):
        raise activities.InvalidAccountError(f'Invalid account {account_id}')

    monkeypatch.setattr(activities, 'check_account', mock_check_account)
    monkeypatch.setattr(activities, 'calculate_refund_amount', mock_calculate_refund_amount)

    account_id = 999
    amount = 100.0
    confirmation = True

    with pytest.raises(activities.InvalidAccountError, match='Invalid account 999'):
        refund(account_id, amount, confirmation)

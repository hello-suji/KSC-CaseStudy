import sys
import pytest
import importlib

@pytest.mark.skipif(sys.version_info < (3, 6), reason="requires python3.6+")
def test_refund_branch_hits_L58_confirm_true_and_L62_edge_cases():
    modules = importlib.import_module('activities')
    refund = getattr(modules, 'refund', None)

    if refund is None:
        pytest.skip('refund function is not available')

    # Parameters to take the branch where confirmation is True and test edge case to hit line 58 & 62
    amount = -10  # Assume negative amount as an edge case for certain logic
    confirmation = True

    try:
        result = refund(amount=amount, confirmation=confirmation)
        # Line 59, 62: Check condition in logic related to negative amount or different branch in refund
        assert result == 'Invalid refund amount'
    except ValueError as e:
        assert str(e) == 'Amount must be non-negative'

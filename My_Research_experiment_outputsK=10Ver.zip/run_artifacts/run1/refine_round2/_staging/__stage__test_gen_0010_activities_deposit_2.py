import pytest
import importlib

try:
    activities = importlib.import_module('activities')
    deposit_func = getattr(activities, 'deposit', None)
except ImportError:
    deposit_func = None
    activities = None


def test_deposit_hits_L46_L50():
    if deposit_func is None:
        pytest.skip('The deposit function is not implemented in the activities module.')
    
    account = {'balance': 100}
    amount = 0

    try:
        deposit_func(account, amount)
    except ValueError as e:
        assert str(e) == 'Deposit amount must be positive', "Unexpected exception message"

    account = {'balance': 100}
    amount = 50

    deposit_func(account, amount)  # This should be successful

    assert account['balance'] == 150, "Balance should increase by 50"
